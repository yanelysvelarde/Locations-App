//
//  Homework4_ShellApp.swift
//  Homework4_Shell
//
//  Created by hasen on 6/12/24.
//

import SwiftUI

@main
struct Homework4_ShellApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
